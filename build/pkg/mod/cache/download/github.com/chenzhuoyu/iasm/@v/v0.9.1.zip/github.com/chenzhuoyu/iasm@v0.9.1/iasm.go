package iasm

import (
    _ `github.com/chenzhuoyu/iasm/expr`
    _ `github.com/chenzhuoyu/iasm/obj`
    _ `github.com/chenzhuoyu/iasm/repl`
    _ `github.com/chenzhuoyu/iasm/x86_64`
)
