# base64x

High performance drop-in replacement of the `encoding/base64` library.

